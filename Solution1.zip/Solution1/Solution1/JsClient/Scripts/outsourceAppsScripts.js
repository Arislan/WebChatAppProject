﻿/// <reference path="jquery-2.0.3.min.js" />

function pubnubSubscribe(root, channel) {
    PUBNUB.subscribe({
        channel: channel,
        callback: function (message) {
            $('#' + root + ' .messageWindow').append('<p>' + message + '</p>');
        }
    });
};