﻿/// <reference path="q.js" />
/// <reference path="jquery-2.0.3.min.js" />
var repository = (function (root) {
    var getRequest = function (url) {
        var promiseObject = Q.defer();

        $.ajax({
            url: root + url,
            type: "get",
            contentType: "application/json",
            success: function (successData) {
                promiseObject.resolve(successData);
            },
            error: function (errorData) {
                promiseObject.reject(errorData);
            }
        });

        return promiseObject.promise;
    }

    var postRequest = function (url, data) {
        var promiseObject = Q.defer();

        $.ajax({
            url: root + url,
            type: "post",
            data: JSON.stringify(data),
            contentType: "application/json",
            success: function (successData) {
                promiseObject.resolve(successData);
            },
            error: function (errorData) {
                promiseObject.reject(errorData);
            }
        });

        return promiseObject.promise;
    }

    return {
        get: getRequest,
        post :postRequest
    }
})('http://localhost:49501/api/');

var usersRepo = (function (root) {
    //api/users/ - get all users - GET
    function getAll() {
        return repository.get(root);
    }

    return {
        all :getAll
    }

})('users/');

var channelsRepo = (function (root) {
    //api/channels - POST - parameter Channel with name and users
    function createChannel() {
        var inputData = document.getElementById('chatRoomName');
        var name = inputData.value;
        inputData.value = '';

        if (!name) {
            document.getElementById('console').
                appendChild(document.createElement('p').appendChild(document.createTextNode('You Need Channel Name !')));
        }

        var users = [{ Id : localStorage.getItem('userId') }];

        var onlineUsers = $('#usersTab option');
        for(var i = 0; i < onlineUsers.length; i++)
        {
            if(onlineUsers[i].selected)
            {
                onlineUsers[i].selected = false;
                users.push( {Id : onlineUsers[i].id.substring(4)});
            }
        }

        repository.post(root, { Name: name, Users: users });

        openNewChannel(name);
    }

    //api/channel/channelname = get all users in this channel - GET
    function channelUsers(name) {
        return repository.get(root + name);
    }
    return {
        create: createChannel,
        getUsers: channelUsers
    }
}('channel/'));

var messagesRepo = (function (root) {

    function sendMessage(data) {

        repository.post(root, data);
    }

    return {
        send: sendMessage,

    }
}('messages/'));