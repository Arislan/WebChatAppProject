﻿/// <reference path="jquery-2.0.3.min.js" />

var chatObjectModule = (function (root) {

    function createChat(id) {
        var chatObject = document.createElement('div');
        chatObject.className = 'chatObject';

        chatObject.appendChild(createMessageWindow());
        chatObject.appendChild(createUserList());
        chatObject.appendChild(createConsole());
        chatObject.id = id;

        document.getElementById(root).appendChild(chatObject);

        $('#sendButton').on('click', function (evt) {
            var textWindow = document.getElementById('textWindow');
            var value = textWindow.value;
            textWindow.value = '';
            var sender = localStorage.getItem('userId');
            messagesRepo.send({ Sender: 'Default', Channel: document.getElementsByClassName('chatObject')[0].id, Content: value, SenderId: sender || 1 });
        });
        document.getElementById('textWindow').addEventListener('keyup', function (evt) {
            if (!evt) {
                evt = window.event;
            }

            if (evt.keyCode == 13) {
                $('#sendButton').trigger('click');
            }
        });

        pubnubSubscribe(id, id);

        $('#console').prepend('<p>Channel "' + id + '" Created !</p>');
        $('#textWindow').attr('placeholder', 'You Are In "' + id + '" Channel !');
    }

    function removeChat(id) {
        document.getElementById(root).
            removeChild(document.getElementById(id));
    }

    function createMessageWindow() {
        var container = document.createElement('div');
        container.className = 'messageWindow';

        return container;
    }

    function createUserList() {
        var container = document.createElement('div');
        container.className = 'usersListContainer';

        var usersList = document.createElement('ul');
        usersList.id = 'usersList';

        container.appendChild(usersList);

        return container;
    }

    function createConsole() {
        var container = document.createElement('div');
        container.className = 'chatConsole';

        var textWindow = document.createElement('textarea');
        textWindow.id = 'textWindow';
        container.appendChild(textWindow);

        var sendBtn = document.createElement('button');
        sendBtn.id = 'sendButton';
        sendBtn.appendChild(document.createTextNode('Send'));
        container.appendChild(sendBtn);

        return container;
    }

  

    function setUpPubNub(el) {

    }

    return {
        create: createChat,
        remove: removeChat
    }
}('chatWindows'));