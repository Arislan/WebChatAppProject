﻿//api/users - get method - array of Users with Id and Name
function updateUsers(data) {
    usersRepo.all().then(function (data) {
        var selectedOptions = [];
        var usersTab = document.getElementById('usersTab');
        var firstChild;
        while (usersTab.hasChildNodes()) {
            firstChild = usersTab.firstChild;
            if (firstChild.selected == true) {
                selectedOptions.push(firstChild.id);
            }
            usersTab.removeChild(usersTab.firstChild);
        }
        var option;
        for (var i = 0; i < data.length; i++) {

            option = document.createElement('option');
            option.id = 'user' + data[i].Id;

            if (selectedOptions.indexOf(option.id) >= 0) {
                option.selected = true;
            }
            option.appendChild(document.createTextNode(data[i].Name));
            usersTab.appendChild(option);
        }
    }, function (error) {
        console.log(error);
    })
};

//not server method
function openNewChannel(channel) {
    var currentChat = document.getElementsByClassName('chatObject')[0];

    if (currentChat) {
        var activeChannels = document.getElementById('activeChannels');
        var newTab = document.createElement('span');
        newTab.id = 'tab_id_' + currentChat.id;
        newTab.innerHTML = currentChat.id;
        activeChannels.appendChild(newTab);
        
        currentChat.parentNode.removeChild(currentChat);
    }

    chatObjectModule.create(channel);
}

//api/channel/channelName -> get method returning all users in channel with this name
function updateCurrentChat() {
    var currentChat = document.getElementsByClassName('chatObject')[0];

    if (currentChat) {
        channelsRepo.getUsers(currentChat.id).then(
            function (data) {
                var list = document.getElementById('usersList');

                while (list.hasChildNodes()) {
                    list.removeChild(list.firstChild);
                }

                var liItem;
                for (var i = 0; i < data.length; i++) {
                    liItem = document.createElement('li');
                    liItem.innerHTML = data[i].Name;
                    liItem.id = 'c_u_' + data[i].Id;
                    list.appendChild(li);
                }
            },
            function (error) {
                cosnole.log('USER CHANNEL UPDATE FAUL - > ' + error)
            }
            );
    }
}