﻿using MvcApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MvcApplication1.Controllers
{
    public class UsersController : ApiController
    {
        private List<User> users = new List<User>
        {
            new User {Id = 1, Name = "Ivan"},
            new User {Id =2,Name ="Pesho"},
            new User {Id = 3, Name= "Batman"},
              new User {Id = 4, Name= "Rambo"}
        };
        // GET api/users
        public IEnumerable<User> Get()
        {
            return users;
        }

        // GET api/users/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/users
        public void Post([FromBody]string value)
        {
        }

        // PUT api/users/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/users/5
        public void Delete(int id)
        {
        }
    }
}
