﻿var toDoList = (function () {
    var tasks = new Array();

    var container = document.createElement('div');
    container.id = 'container';

    var div = document.createElement('div');
    div.id = 'control';

    var input = document.createElement('textarea');
    input.setAttribute('placeholder',
        'Type Some Text And Click "Add Item" OR Press "Enter" To Add Text In List !');
    input.addEventListener('keyup', function (evt) {
        if (!evt) {
            evt = window.event;
        }

        if (evt.keyCode == 13) {
            addTask();
        }
    });
    div.appendChild(input);

    var addBtn = document.createElement('button');
    addBtn.id = 'add';
    addBtn.innerHTML = 'Add Item';
    div.appendChild(addBtn);
    addBtn.addEventListener('click', addTask);

    div.appendChild(document.createElement('hr'));

    var removeBtn = document.createElement('button');
    removeBtn.id = 'remove';
    removeBtn.innerHTML = 'Remove Item';
    div.appendChild(removeBtn);
    removeBtn.addEventListener('click', removeTask);

    var select = document.createElement('select');
    div.appendChild(select);

    var markBtn = document.createElement('button');
    markBtn.id = 'mark';
    markBtn.innerHTML = 'Mark As Important';
    div.appendChild(markBtn);
    markBtn.addEventListener('click', function () {
        var task = select.value;
        tasks[task] = '<span style="color:red">' + tasks[task] + '</span>';
        displayTasks(true);
    });

    div.appendChild(document.createElement('hr'));

    var loadSaveInput = document.createElement('input');
    loadSaveInput.setAttribute('type', 'text');
    loadSaveInput.setAttribute('placeholder', 'List Name To Load/Save');
    div.appendChild(loadSaveInput);

    var loadBtn = document.createElement('button');
    loadBtn.id = 'load';
    loadBtn.innerHTML = 'Load List';
    div.appendChild(loadBtn);
    loadBtn.addEventListener('click', function () {
        var name = loadSaveInput.value || 'toDoList';
        var text = localStorage.getItem(name);
        tasks = text.split(';');
        displayTasks(true);
        makeFreshOptionList();
    });

    var saveBtn = document.createElement('button');
    saveBtn.id = 'save';
    saveBtn.innerHTML = 'Save List';
    div.appendChild(saveBtn);
    saveBtn.addEventListener('click', function () {
        var text = tasks.join(';');
        var name = loadSaveInput.value || 'toDoList';
        localStorage.setItem(name, text);
    });

    container.appendChild(div);

    var display = document.createElement('div');
    display.id = 'display';
    container.appendChild(display);

    var heading = document.createElement('h2');
    heading.innerHTML = 'TO DO LIST : ';
    display.appendChild(heading);

    var ol = document.createElement('ol');
    display.appendChild(ol);
    display = ol;

    document.body.appendChild(container);

    function addOption() {
        if (select.hasChildNodes()) {
            select.lastChild.removeAttribute('selected');
        }

        var option = document.createElement('option');
        option.innerHTML = tasks.length;
        option.value = tasks.length - 1;
        option.setAttribute('selected', 'selected');
        select.appendChild(option);
    }

    function makeFreshOptionList() {
        while (select.hasChildNodes()) {
            select.removeChild(select.firstChild);
        }

        var option;
        for (var i = 0; i < tasks.length; i++) {
            option = document.createElement('option');
            option.innerHTML = i + 1;
            option.value = i;
            select.appendChild(option);
        }
    }

    function addTask() {
        var text = input.value;
        input.value = '';
        tasks.push(text);
        addOption();
        displayTasks();
    }

    function displayTasks(reOrder) {
        var li;
        if (reOrder) {
            while (display.hasChildNodes()) {
                display.removeChild(display.firstChild);
            }
        }

        var startIndex = display.childElementCount;
        for (var i = startIndex ; i < tasks.length; i++) {
            li = document.createElement('li');
            li.innerHTML = tasks[i];
            display.appendChild(li);
        }
    }

    function removeTask() {
        var task = select.value;
        tasks.splice(task, 1);
        select.removeChild(select.lastChild);
        displayTasks(true);
    }
}());