﻿/// <reference path="q.js" />
/// <reference path="jquery-2.0.3.min.js" />
var repository = (function (root) {
    var getRequest = function (url) {
        var promiseObject = Q.defer();

        $.ajax({
            url: root + url,
            type: "get",
            contentType: "application/json",
            success: function (successData) {
                promiseObject.resolve(successData);
            },
            error: function (errorData) {
                promiseObject.reject(errorData);
            }
        });

        return promiseObject.promise;
    }

    var postRequest = function (url, data) {
        var promiseObject = Q.defer();

        $.ajax({
            url: root + url,
            type: "post",
            data: JSON.stringify(data),
            contentType: "application/json",
            success: function (successData) {
                promiseObject.resolve(successData);
            },
            error: function (errorData) {
                promiseObject.reject(errorData);
            }
        });

        return promiseObject.promise;
    }

    return {
        get: getRequest,
        post :postRequest
    }
})('http://localhost:49501/api/');

var usersRepo = (function (root) {

    function getAll() {
        return repository.get(root);
    }

    return {
        all :getAll
    }

})('users/');
