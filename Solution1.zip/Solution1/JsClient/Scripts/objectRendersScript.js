﻿var chatObjectModule = (function (root) {

    function createChat(id) {
        var chatObject = document.createElement('div');
        chatObject.className = 'chatObject';

        chatObject.appendChild(createMessageWindow());
        chatObject.appendChild(createUserList());
        chatObject.appendChild(createConsole());
        chatObject.id = id;

        document.getElementById(root).appendChild(chatObject);
    }

    function removeChat(id) {
        document.getElementById(root).
            removeChild(document.getElementById(id));
    }

    function createMessageWindow() {
        var container = document.createElement('div');
        container.className = 'messageWindow';

        return container;
    }

    function createUserList() {
        var container = document.createElement('div');
        container.className = 'usersListContainer';

        var usersList = document.createElement('ul');
        usersList.className = 'usersList';

        container.appendChild(usersList);

        return container;
    }

    function createConsole() {
        var container = document.createElement('div');
        container.className = 'chatConsole';

        var textWindow = document.createElement('textarea');
        textWindow.className = 'textWindow';
        container.appendChild(textWindow);

        var sendBtn = document.createElement('button');
        sendBtn.className = 'sendButton';
        sendBtn.appendChild(document.createTextNode('Send'));
        container.appendChild(sendBtn);

        return container;
    }

    function setUpPubNub(el) {

    }

    return {
        create: createChat,
        remove: removeChat
    }
}('chatWindows'));