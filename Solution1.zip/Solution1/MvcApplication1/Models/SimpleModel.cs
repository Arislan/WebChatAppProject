﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }

    public class Channel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public List<User> Users { get; set; }


        
    }

    public class Message
    {
        public int Id { get; set; }

        public string Content { get; set; }

        public int SenderId { get; set; }

        public string Sender { get; set; }
        public string Channel { get; set; }
    }
}