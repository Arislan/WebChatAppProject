﻿using MvcApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MvcApplication1.Controllers
{
    public class MessagesController : ApiController
    {
        public List<Message> mess = new List<Message>();
        // GET api/messages
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/messages/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/messages
        public void Post([FromBody]Message value)
        {
            mess.Add(value);
            PubnubAPI pubnub = new PubnubAPI(
            "pub-c-01dc0145-d006-4cc3-b34f-5b4f101cdaa5",               // PUBLISH_KEY
            "sub-c-3e6b5fb6-04d9-11e3-8dc9-02ee2ddab7fe",               // SUBSCRIBE_KEY
            "sec-c-NWI4MThmOTYtNWE1My00MmVlLWI1ZTktNzZmODgyOTIyZWY0",   // SECRET_KEY
            true                                                        // SSL_ON?
        );
            //string channel = "someChannel";

            pubnub.Publish(value.Channel, "[" + DateTime.Now.ToString("dd-MMM-yyyy ss:mm:ss") + "]" + value.Sender + " - > "  + value.Content);
        }

        // PUT api/messages/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/messages/5
        public void Delete(int id)
        {
        }
    }
}
