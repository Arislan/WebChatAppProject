﻿using MvcApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MvcApplication1.Controllers
{
    public class ChannelController : ApiController
    {
        public List<Channel> channels = new List<Channel>();
        // GET api/channels
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/channels/5
        public IEnumerable<User> Get(string id)
        {
            return channels.FirstOrDefault(x => x.Name == id).Users;
        }

        // POST api/channels
        public void Post([FromBody]Channel value)
        {
           
           channels.Add(new Channel { Name = value.Name, Users = value.Users });
        }

        // PUT api/channels/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/channels/5
        public void Delete(int id)
        {
        }
    }
}
